﻿using ASPNET.StarterKit.Commerce.AzureFeatures;
using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Indexes.Models;
using Azure.Search.Documents.Models;
using IBuySpyCommon.Models;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace ASPNET.StarterKit.Commerce
{
    public partial class SearchResults2 : System.Web.UI.Page
    {
        private static SearchClient _searchClient;
        private static readonly TelemetryClient _appInsights = new TelemetryClient();
        public static string errorMessage;

        protected void Page_Load(object sender, EventArgs e)
        {
            string term = Request.Params[IBuySpyCommon.Strings.QueryStrings.Searchterm];
            string productSearchTerm = string.Empty;
            errorPanel.Visible = false;
            resultsPanel.Visible = false;
            EventTelemetry searchEvent = new EventTelemetry();
            // Search database using the supplied "txtSearch" parameter
            _appInsights.InstrumentationKey = TelemetryConfiguration.Active.InstrumentationKey;

            //Parse for bad input
            if (!string.IsNullOrEmpty(term))
            {
                productSearchTerm = HttpUtility.HtmlEncode(term);
            }

            searchEvent.Name = "search";
            searchEvent.Properties.Add("searchpage", "search2");
            searchEvent.Properties.Add("searchterm", productSearchTerm);
            _appInsights.TrackPageView("searchresults2");

            // Databind and display the list of search result product items
            try
            {
                int productsFound = 0;
                if (!string.IsNullOrEmpty(productSearchTerm))
                {
                    // Send the event:
                    // Create an HTTP reference to the catalog index
                    _searchClient = CreateSearchClient();
                    List<ProductSearchResult> products = SearchProducts(term);
                    MyList2.DataSource = products;
                    MyList2.DataBind();
                    productsFound = products.Count;
                    errorPanel.Visible = false;
                    resultsPanel.Visible = true;
                }

                if (productsFound > 0)
                {
                    //We found some results
                    searchEvent.Properties.Add("results", productsFound.ToString());
                }
                else
                {
                    //No search results found
                    searchEvent.Properties.Add("noresultsfound", productSearchTerm);
                    _appInsights.TrackEvent(searchEvent);
                    errorPanel.Visible = true;
                    resultsPanel.Visible = false;
                }
                //Send an event
                _appInsights.TrackEvent(searchEvent);
            }
            catch (Exception ex)
            {
                //TODO: If we cannot connect to the search service, fall back to regular search
                ExceptionTelemetry searchException = new ExceptionTelemetry(ex)
                {
                    Message = "Unable to execute search. Disabling Azure search"
                };
                _appInsights.TrackException(searchException);

                ConfigurationManager.AppSettings["UseAzureSearch"] = false.ToString();
                Response.Redirect($"searchresults.aspx?t={term}", true);
            }

            searchTerm.Text = term;
            // Display a message if no results are found
            if (MyList2.Items.Count == 0)
            {
                ErrorMsg2.Text = $"No items matched your query [{productSearchTerm}].";
                errorPanel.Visible = true;
                resultsPanel.Visible = false;
            }
            else
            {
                errorPanel.Visible = false;
                resultsPanel.Visible = true;
            }
        }

        private static SearchClient CreateSearchClient()
        {
            string searchServiceEndpointUri = ConfigurationManager.AppSettings["SearchServiceEndpoint"];
            string queryApiKey = ConfigurationManager.AppSettings["SearchServiceQueryApiKey"];
            string productIndexName = ConfigurationManager.AppSettings["SearchServiceIndexName"];
            if (string.IsNullOrEmpty(searchServiceEndpointUri) || string.IsNullOrEmpty(queryApiKey) || string.IsNullOrEmpty(productIndexName))
            {
                throw new ConfigurationErrorsException("Invalid Search Service configuration. Check the URI, indexname and key");
            }
            AzureKeyCredential searchServiceCredential = new AzureKeyCredential(queryApiKey);
            Uri searchServiceUri = new Uri(searchServiceEndpointUri);
            SearchClient searchClient = new SearchClient(searchServiceUri, productIndexName, searchServiceCredential);

            return searchClient;
        }

        private static List<ProductSearchResult> SearchProducts(string searchterm)
        {
            List<ProductSearchResult> results = new List<ProductSearchResult>();

            try
            {
                SearchOptions so = new SearchOptions()
                {
                    SearchMode = SearchMode.Any,
                    IncludeTotalCount = true
                };
                SearchResults<ProductSearchResult> searchResults = _searchClient.Search<ProductSearchResult>(searchterm, so);

                if (searchResults.TotalCount > 0)
                {
                    foreach (var result in searchResults.GetResults())
                    {
                        ProductSearchResult p = new ProductSearchResult()
                        {
                            ProductID = result.Document.ProductID,
                            Description = result.Document.Description,
                            ModelName = result.Document.ModelName,
                            ModelNumber = result.Document.ModelNumber,
                            ProductImage = IBuySpyFeatures.BuildProductImageUrl(result.Document.ProductImage, IBuySpyCommon.RuntimeConstants.ImageSize.Medium),
                            UnitCost = result.Document.UnitCost,
                            Price = double.Parse(String.Format("{0:c}", result.Document.UnitCost))
                        };
                        results.Add(p);
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = $"Error querying index: {ex.Message}\r\n";
                ExceptionTelemetry searchException = new ExceptionTelemetry(ex)
                {
                    Message = "An error occured acessing the search service"
                };
                _appInsights.TrackException(searchException);
            }

            return results;
        }
    }
}