﻿using Microsoft.Azure;
using System.Configuration;

namespace ASPNET.StarterKit.Commerce
{
    public static class DataConnection
    {
        public static string GetConnString()
        {
            string dataConnKey = CloudConfigurationManager.GetSetting("DataConnectionString");
            string connstring = ConfigurationManager.ConnectionStrings[dataConnKey].ConnectionString;
            return connstring;
        }
    }
}