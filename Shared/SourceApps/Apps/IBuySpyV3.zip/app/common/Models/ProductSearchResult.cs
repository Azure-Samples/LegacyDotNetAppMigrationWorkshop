﻿using Azure.Search.Documents.Indexes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;


namespace IBuySpyCommon.Models
{
    public class ProductSearchResult
    {
        [SearchableField(IsKey = true, IsSortable =true)]
        public string ProductID { get; set; }

        [SimpleField(IsFilterable = true, IsSortable = true)]
        public Int32 CategoryID { get; set; }

        [SearchableField(IsSortable = true)]
        public string ModelNumber { get; set; }
        
        [SearchableField(IsSortable = true)]
        public string ModelName { get; set; }
        
        [SimpleField()]
        public string ProductImage { get; set; }

        [SearchableField(IsFilterable = true, IsSortable = true)]
        public string UnitCost { get; set; }
        
        [SearchableField()]
        public string Description { get; set; }

        [SearchableField()]
        public List<string> KeyPhrases { get; set; }
        
        [JsonIgnore]
        public double Price { get; set; }
    }
}
